from test.TestBase import WorldTestBase
from .Game import game_name


class ManualTest(WorldTestBase):
    game = game_name
